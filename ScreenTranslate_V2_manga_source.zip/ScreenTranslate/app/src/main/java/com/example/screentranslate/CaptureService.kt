package com.example.screentranslate

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.TextRecognizer

class CaptureService : Service() {
    companion object { const val ACTION_START = "capture.start"; const val ACTION_STOP = "capture.stop" }
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var wm: WindowManager? = null
    private var overlay: TranslationOverlay? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var stopButton: TextView? = null
    private var busy = false
    private var mangaMode = false
    private var active = false
    private var widthPx = 0
    private var heightPx = 0
    private var densityDpi = 0
    private val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val japanese = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
    private val korean = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    private val identifier = LanguageIdentification.getClient()
    private val translators = mutableMapOf<String, Translator>()
    private val modelReady = mutableSetOf<String>()
    private val pendingModels = mutableSetOf<String>()
    private val tick = object : Runnable {
        override fun run() {
            if (!active) return
            if (!busy) captureOnce()
            main.postDelayed(this, 1600L)
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action != ACTION_START || active) return START_NOT_STICKY
        mangaMode = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("manga", true)
        val code = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("resultData", Intent::class.java)
                   else intent.getParcelableExtra("resultData") as? Intent
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val channel = "screen_translate_capture"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(channel, "屏幕翻译运行中", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(this, 0, Intent(this, CaptureService::class.java).apply { action = ACTION_STOP }, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this, channel).setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("屏幕实时翻译").setContentText("正在识别屏幕 · 点击停止可结束")
            .addAction(Notification.Action.Builder(null, "停止", stopIntent).build()).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(11, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(11, notification)
        try {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm!!.defaultDisplay.getRealMetrics(metrics)
            widthPx = metrics.widthPixels; heightPx = metrics.heightPixels; densityDpi = metrics.densityDpi
            reader = ImageReader.newInstance(widthPx, heightPx, android.graphics.PixelFormat.RGBA_8888, 2)
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projection!!.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
            virtualDisplay = projection!!.createVirtualDisplay("ScreenTranslate", widthPx, heightPx, densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, main)
            overlay = TranslationOverlay(this).also { view ->
                // Full-screen translation layer never intercepts touches or focus.
                overlayParams = WindowManager.LayoutParams(widthPx, heightPx,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
                wm!!.addView(view, overlayParams)
            }
            stopButton = TextView(this).apply {
                text = "停止翻译"
                textSize = 13f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(Color.argb(225, 35, 45, 60))
                    cornerRadius = 32f * resources.displayMetrics.density
                }
                setOnClickListener { stopSelf() }
            }.also { button ->
                val dp = resources.displayMetrics.density
                wm!!.addView(button, WindowManager.LayoutParams(
                    (92 * dp).toInt(), (42 * dp).toInt(),
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    android.graphics.PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.END; x = (12 * dp).toInt(); y = (75 * dp).toInt() })
            }
            active = true; main.postDelayed(tick, 600)
        } catch (e: Exception) { android.util.Log.e("ScreenTranslate", "Cannot start capture", e); stopSelf() }
        return START_NOT_STICKY
    }
    private fun captureOnce() {
        val r = reader ?: return
        busy = true
        // Hide our own translations for the next captured frame to avoid translating our output.
        overlay?.showTranslations = false
        stopButton?.visibility = View.INVISIBLE
        main.postDelayed({
            if (!active) { busy = false; return@postDelayed }
            val image = r.acquireLatestImage()
            if (image == null) { overlay?.showTranslations = true; stopButton?.visibility = View.VISIBLE; busy = false; return@postDelayed }
            val bitmap = try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val paddedWidth = plane.rowStride / plane.pixelStride
                val padded = Bitmap.createBitmap(paddedWidth, heightPx, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                Bitmap.createBitmap(padded, 0, 0, widthPx, heightPx).also { padded.recycle() }
            } catch (e: Exception) { null } finally { image.close() }
            overlay?.showTranslations = true
            stopButton?.visibility = View.VISIBLE
            if (bitmap == null) { busy = false; return@postDelayed }
            recognize(bitmap)
        }, 140L)
    }
    private fun recognize(bitmap: Bitmap) {
        val image = InputImage.fromBitmap(bitmap, 0)
        val recognizers = listOf(latin, japanese, korean)
        val lines = mutableListOf<Pair<String, Rect>>()
        fun next(i: Int) {
            if (i >= recognizers.size) {
                bitmap.recycle()
                translateLines(if (mangaMode) MangaTextLayout.groupVertical(lines) else lines.distinctBy { it.first to it.second.top })
                return
            }
            recognizers[i].process(image).addOnSuccessListener { result ->
                for (block in result.textBlocks) for (line in block.lines) {
                    val value = line.text.trim()
                    val box = line.boundingBox
                    if (box != null && value.length >= 2 && lines.none { Rect.intersects(it.second, box) }) lines.add(value to Rect(box))
                }
            }.addOnCompleteListener { next(i + 1) }
        }
        next(0)
    }
    private fun translateLines(lines: List<Pair<String, Rect>>) {
        if (!active) { busy = false; return }
        if (lines.isEmpty()) { overlay?.setItems(emptyList(), mangaMode); busy = false; return }
        val output = mutableListOf<Pair<String, Rect>>()
        var index = 0
        fun next() {
            if (!active) { busy = false; return }
            if (index >= lines.size) {
                overlay?.setItems(output, mangaMode)
                busy = false
                return
            }
            val (source, rect) = lines[index++]
            identifier.identifyLanguage(source).addOnSuccessListener { language ->
                val code = when (language) { "und" -> if (source.any { it.code in 0x3040..0x30ff }) "ja" else if (source.any { it.code in 0xac00..0xd7af }) "ko" else "en"; else -> language.substringBefore('-') }
                if (code == "zh" || !TranslateLanguage.getAllLanguages().contains(code)) { next(); return@addOnSuccessListener }
                val translator = translators.getOrPut(code) {
                    Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(code).setTargetLanguage(TranslateLanguage.CHINESE).build())
                }
                if (!modelReady.contains(code)) {
                    if (pendingModels.add(code)) translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                        .addOnSuccessListener { modelReady.add(code) }
                        .addOnCompleteListener { pendingModels.remove(code) }
                    next()
                } else {
                    translator.translate(source).addOnSuccessListener { translated ->
                        if (translated.isNotBlank()) output.add(translated to rect)
                    }.addOnCompleteListener { next() }
                }
            }.addOnFailureListener { next() }
        }
        next()
    }
    override fun onDestroy() {
        active = false; main.removeCallbacksAndMessages(null)
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { stopButton?.let { wm?.removeView(it) } } catch (_: Exception) {}
        latin.close(); japanese.close(); korean.close(); identifier.close(); translators.values.forEach { it.close() }
        super.onDestroy()
    }
}

/** Touch-through overlay. Uses sampled flat background where possible; no neural inpainting. */
class TranslationOverlay(context: Context) : View(context) {
    var showTranslations = true
        set(value) { field = value; invalidate() }
    private var items: List<Pair<String, Rect>> = emptyList()
    private var manga = false
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; typeface = Typeface.DEFAULT_BOLD }
    fun setItems(value: List<Pair<String, Rect>>, mangaMode: Boolean = false) {
        items = value.toList(); manga = mangaMode; invalidate()
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!showTranslations) return
        for ((translation, raw) in items) {
            if (translation.isBlank()) continue
            val left = raw.left.coerceIn(0, width - 1).toFloat()
            val top = raw.top.coerceIn(0, height - 1).toFloat()
            val availableWidth = (width - left - 8).coerceAtLeast(40f)
            val boxWidth = if (manga) (raw.width() * 1.35f).coerceIn(76f, availableWidth)
                           else (raw.width() * 1.5f).coerceIn(100f, availableWidth)
            val fontSize = if (manga) (raw.height() / 3f).coerceIn(16f, 35f)
                           else (raw.height() * .7f).coerceIn(16f, 38f)
            textPaint.textSize = fontSize
            val lines = MangaTextLayout.wrapChinese(translation, textPaint, boxWidth - 14f)
            val lineHeight = fontSize * 1.24f
            val boxHeight = (lines.size * lineHeight + 12f).coerceAtLeast(raw.height().toFloat())
            val rect = RectF(left, top, (left + boxWidth).coerceAtMost(width.toFloat()), (top + boxHeight).coerceAtMost(height.toFloat()))
            // Opaque fill works for speech bubbles, not textured manga backgrounds.
            backgroundPaint.color = Color.WHITE
            canvas.drawRoundRect(rect, if (manga) 8f else 4f, if (manga) 8f else 4f, backgroundPaint)
            lines.forEachIndexed { index, line ->
                canvas.drawText(line, left + 7f, top + 6f + fontSize + index * lineHeight, textPaint)
            }
        }
    }
}
