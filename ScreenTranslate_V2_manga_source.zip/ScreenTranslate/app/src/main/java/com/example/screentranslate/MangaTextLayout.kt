package com.example.screentranslate

import android.graphics.Paint
import android.graphics.Rect
import kotlin.math.abs

/** Heuristic for vertical Japanese OCR: group short boxes in the same column, right to left. */
object MangaTextLayout {
    fun groupVertical(source: List<Pair<String, Rect>>): List<Pair<String, Rect>> {
        val remaining = source.filter { it.first.isNotBlank() }.toMutableList()
        val result = mutableListOf<Pair<String, Rect>>()
        while (remaining.isNotEmpty()) {
            val seed = remaining.removeAt(0)
            val column = mutableListOf(seed)
            if (seed.second.height() >= seed.second.width() * 0.65f) {
                val candidates = remaining.filter { item ->
                    val a = seed.second; val b = item.second
                    val centerDistance = abs(a.centerX() - b.centerX())
                    centerDistance < maxOf(a.width(), b.width()) * .8f &&
                        abs(a.centerY() - b.centerY()) < maxOf(a.height(), b.height()) * 5
                }
                column.addAll(candidates)
                remaining.removeAll(candidates.toSet())
            }
            val sorted = column.sortedBy { it.second.top }
            val bounds = Rect(sorted.first().second)
            sorted.drop(1).forEach { bounds.union(it.second) }
            result.add(sorted.joinToString("") { it.first.replace("\n", "") } to bounds)
        }
        return result.sortedWith(compareByDescending<Pair<String, Rect>> { it.second.centerX() }.thenBy { it.second.top })
    }
    fun wrapChinese(text: String, paint: Paint, maxWidth: Float): List<String> {
        val lines = mutableListOf<String>()
        var current = ""
        for (char in text) {
            if (char == '\n') { if (current.isNotEmpty()) lines.add(current); current = ""; continue }
            val next = current + char
            if (current.isNotEmpty() && paint.measureText(next) > maxWidth) {
                lines.add(current); current = char.toString()
            } else current = next
        }
        if (current.isNotEmpty()) lines.add(current)
        return lines.ifEmpty { listOf("") }
    }
}
