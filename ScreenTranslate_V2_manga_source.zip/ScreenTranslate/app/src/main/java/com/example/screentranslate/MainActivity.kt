package com.example.screentranslate

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.CheckBox

class MainActivity : Activity() {
    private val captureCode = 100
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 65, 40, 30) }
        layout.addView(TextView(this).apply { text = "屏幕实时翻译\n\n启动后自动识别屏幕外语，并在原位置覆盖中文。首次翻译需要联网下载语言模型。\n\n请先授权悬浮窗权限。"; textSize = 19f })
        val mangaToggle = CheckBox(this).apply {
            text = "漫画模式（竖排日文 / 背景填充 / 中文排版）"
            isChecked = getSharedPreferences("settings", MODE_PRIVATE).getBoolean("manga", true)
            setOnCheckedChangeListener { _, checked -> getSharedPreferences("settings", MODE_PRIVATE).edit().putBoolean("manga", checked).apply() }
        }
        layout.addView(mangaToggle)
        layout.addView(Button(this).apply { text = "1. 授予悬浮窗权限"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } })
        layout.addView(Button(this).apply { text = "2. 开始实时翻译"; setOnClickListener {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                android.widget.Toast.makeText(this@MainActivity, "请先允许悬浮窗", android.widget.Toast.LENGTH_LONG).show()
            } else {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureCode)
            }
        } })
        layout.addView(Button(this).apply { text = "停止翻译"; setOnClickListener {
            startService(Intent(this@MainActivity, CaptureService::class.java).apply { action = CaptureService.ACTION_STOP })
        } })
        setContentView(layout)
    }
    @Deprecated("Uses legacy result API for a compact standalone example")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureCode && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra("resultCode", resultCode)
                putExtra("resultData", data)
            }
            startForegroundService(intent)
        }
    }
}
